家乡双发卡弯驾驶测试 V3（Blender V20）

1. 把 tight_hairpin_drive_v3.zip 复制到 Windows，不解压。
2. 在 BeamNG 启动器选择 Manage User Folder → Open in Explorer，将 ZIP 放入 mods 文件夹。
3. 启动游戏，在 Freeroam 搜索 Hometown Hairpin Drive V3，选择 Main Road。
4. 建议停用旧 V1/V2，以免选错地图。可用游戏内轿车或已安装的合法车辆模组试车。

本版大路净宽5米，不含外侧净宽0.5米、深0.6米排水渠；小路宽3米。
上方小路渠在C1入弯前2米结束，下方渠从C2出弯后4米开始。
小路护栏约7米，弯道口已收短；另一侧无防护陡坎，新增填土路肩、排水渠和土坡均有对应碰撞。
C63仅是本地Blender参考车，不在地图包内；地图不会自动提供可驾驶C63。

按顺序检查：出生与路面支撑 → 小路低速过弯 → 裸石与护栏碰撞 → 排水渠落轮 → 悬崖侧失去支撑 → 保存并重载。
道路摩擦为干燥硬路面试拟值，未按实路校准。已做离线文件与几何检查，尚未在Windows BeamNG内加载和驾驶验证。
如加载或碰撞有问题，请记录游戏版本、位置、表现和beamng.log。
压缩包应直接包含 levels/tight_hairpin_drive_v3/；若存档格式与游戏版本不兼容，用目标版本World Editor创建空地图后对照文件结构。
